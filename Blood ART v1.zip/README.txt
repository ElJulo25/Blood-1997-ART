This is some of my art créations. You are free to use in your map if you feel so.

I'll update my GitHub if i made new creations.
I have some customs sounds still in wip. (Wind, rain etc.)
Feel free to contact me if you have requests or want to know more.

Best regards

El Julo 